package it.unipv.po.splash.model.risikogame.move.placement;

import it.unipv.po.splash.model.risikogame.components.Territory;

public interface IPlacement {
	public void changeTerritory(Territory t);
}
