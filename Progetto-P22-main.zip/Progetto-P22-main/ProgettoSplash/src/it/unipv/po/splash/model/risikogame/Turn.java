package it.unipv.po.splash.model.risikogame;

public class Turn {

}
