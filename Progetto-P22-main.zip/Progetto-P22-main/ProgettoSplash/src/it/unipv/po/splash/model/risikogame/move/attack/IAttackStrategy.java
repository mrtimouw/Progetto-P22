package it.unipv.po.splash.model.risikogame.move.attack;

public interface IAttackStrategy {
	public void estimateLostandKilled(Attack attack);
}
