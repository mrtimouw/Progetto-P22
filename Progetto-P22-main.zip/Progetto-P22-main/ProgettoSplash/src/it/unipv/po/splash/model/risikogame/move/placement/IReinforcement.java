package it.unipv.po.splash.model.risikogame.move.placement;

public interface IReinforcement {
	public void calcolateReinforcements();
}
