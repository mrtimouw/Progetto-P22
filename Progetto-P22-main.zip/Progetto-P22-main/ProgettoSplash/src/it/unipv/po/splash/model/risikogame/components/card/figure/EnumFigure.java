package it.unipv.po.splash.model.risikogame.components.card.figure;

public enum EnumFigure {
	JACK, CANNON, KNIGHT, JOLLY
}
