package it.unipv.po.splash.model.risikogame.factory;
//prendi un file csv con tutti i dettagli dei territori
//e crea una board di risiko 
public class BoardFactory {

}
