package it.unipv.po.splash.model.risikogame.components.card.strategy;


import it.unipv.po.splash.model.risikogame.move.placement.strategy.CardReinforceStrategy;



public interface ITCBonusStrategy {
	public void getCardBonus(CardReinforceStrategy cps);
}
